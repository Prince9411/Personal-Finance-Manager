"use client";
import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

export default function SummaryCards() {
  const [summary, setSummary] = useState({ total: 0, recent: [] });

  useEffect(() => {
    fetch("/api/transactions")
      .then(res => res.json())
      .then(data => {
        const total = data.reduce((sum: number, txn: any) => sum + txn.amount, 0);
        const recent = data.slice(-3).reverse();
        setSummary({ total, recent });
      });
  }, []);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      <Card><CardContent className="p-4">Total Spent: ₹{summary.total}</CardContent></Card>
      <Card><CardContent className="p-4">Recent: {summary.recent[0]?.description || "-"}</CardContent></Card>
      <Card><CardContent className="p-4">Entries: {summary.recent.length}</CardContent></Card>
    </div>
  );
}
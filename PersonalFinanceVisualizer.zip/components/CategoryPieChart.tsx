"use client";
import { useEffect, useState } from "react";
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";

const COLORS = ["#8884d8", "#82ca9d", "#ffc658", "#ff8042", "#8dd1e1"];

export default function CategoryPieChart() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch("/api/transactions")
      .then(res => res.json())
      .then(transactions => {
        const totals: Record<string, number> = {};
        for (const txn of transactions) {
          totals[txn.category] = (totals[txn.category] || 0) + txn.amount;
        }
        setData(Object.entries(totals).map(([name, value]) => ({ name, value })));
      });
  }, []);

  return (
    <div className="my-6">
      <h2 className="text-lg font-semibold mb-2">Category-wise Breakdown</h2>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie dataKey="value" data={data} cx="50%" cy="50%" outerRadius={100}>
            {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
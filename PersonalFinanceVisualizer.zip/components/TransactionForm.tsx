"use client";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectItem } from "@/components/ui/select";

const categories = ["Food", "Transport", "Shopping", "Bills", "Entertainment"];

export default function TransactionForm() {
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState("");
  const [category, setCategory] = useState(categories[0]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !description || !date || !category) return alert("All fields are required");

    await fetch("/api/transactions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount: parseFloat(amount), description, date, category })
    });

    setAmount("");
    setDescription("");
    setDate("");
    setCategory(categories[0]);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-2">
      <Input type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
      <Input placeholder="Description" value={description} onChange={e => setDescription(e.target.value)} />
      <Input type="date" value={date} onChange={e => setDate(e.target.value)} />
      <Select value={category} onValueChange={setCategory}>
        {categories.map((cat) => (
          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
        ))}
      </Select>
      <Button type="submit">Add Transaction</Button>
    </form>
  );
}
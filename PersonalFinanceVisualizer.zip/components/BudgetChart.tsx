"use client";
import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const budgets = { Food: 2000, Transport: 1500, Shopping: 2500, Bills: 3000, Entertainment: 1800 };

export default function BudgetChart() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch("/api/transactions")
      .then(res => res.json())
      .then(transactions => {
        const spent: Record<string, number> = {};
        transactions.forEach(txn => spent[txn.category] = (spent[txn.category] || 0) + txn.amount);

        const chartData = Object.keys(budgets).map(cat => ({
          category: cat,
          Budget: budgets[cat],
          Spent: spent[cat] || 0
        }));

        setData(chartData);
      });
  }, []);

  return (
    <div>
      <h2 className="text-lg font-semibold mb-2">Budget vs Actual</h2>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <XAxis dataKey="category" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="Budget" fill="#82ca9d" />
          <Bar dataKey="Spent" fill="#8884d8" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
import { NextApiRequest, NextApiResponse } from "next";
import { MongoClient } from "mongodb";

const uri = process.env.MONGODB_URI!;

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const client = new MongoClient(uri);
  await client.connect();
  const db = client.db("finance");
  const collection = db.collection("transactions");

  if (req.method === "POST") {
    const { amount, description, date, category } = req.body;
    const result = await collection.insertOne({ amount, description, date, category });
    res.status(200).json(result);
  } else if (req.method === "GET") {
    const result = await collection.find().toArray();
    res.status(200).json(result);
  }

  await client.close();
}
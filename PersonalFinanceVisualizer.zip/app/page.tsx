import TransactionForm from "@/components/TransactionForm";
import TransactionList from "@/components/TransactionList";
import MonthlyChart from "@/components/MonthlyChart";
import CategoryPieChart from "@/components/CategoryPieChart";
import SummaryCards from "@/components/SummaryCards";
import BudgetChart from "@/components/BudgetChart";

export default function Home() {
  return (
    <main className="p-4 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold mb-4">Personal Finance Dashboard</h1>
      <TransactionForm />
      <SummaryCards />
      <MonthlyChart />
      <CategoryPieChart />
      <BudgetChart />
      <TransactionList />
    </main>
  );
}